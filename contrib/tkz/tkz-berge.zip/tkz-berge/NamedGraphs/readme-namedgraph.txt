% encodage utf8    
--------------------  english readme ----------------------------------------
readme-namedgraphs.txt V 1.00 c 26/05/2011 

The file namedgraphs.pdf is not a beginner or advanced tutorial, not a study
 of graphs, it's only a gallery of undirected graphs made with  the package
 tkz-berge.sty v 1.00 c.  Some of  graphs  have names, sometimes inspired by
 the graph's topology, and sometimes after their discoverer. NamedGraphs.pdf
 presents some of them. A lot of references can be found here:
http://mathworld.wolfram.com.

Licence
-------

This document can be redistributed and/or modified under the terms
of the LaTeX Project Public License Distributed from CTAN
archives in directory macros/latex/base/lppl.txt. 

Compilation of the sources  
--------------------------

-- Encoding = utf8
-- Engine = pdflatex 
-- You need the tkz-doc.cls class and tkzexample.sty package.


 Alain Matthes
 5 rue de Valence
 Paris 75005  
 
 al (dot) ma (at) mac (dot) com 
 
               