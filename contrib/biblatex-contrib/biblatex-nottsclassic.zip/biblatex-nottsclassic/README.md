bibLaTeX-__nottsclassic__    
======= 

_2016/06/30 v0.1_

Copyright (c) 2016 Lukas C. Bossert | William Leveritt

Email: [lukas@digitales-altertum.de](mailto:lukas@digitales-altertum.de)

This citation-style covers the citation and bibliography rules of 
the __University of Nottingham__. 

---

This style contains:

documentation:

- nottsclassic.pdf
- nottsclassic.tex

mandatory:

* nottsclassic.cbx
* nottsclassic.bbx

language files:

- nottsclassic-english.lbx


This work may be distributed and/or modified under the
conditions of the LaTeX Project Public License, either version 1.3
of this license or (at your option) any later version.
The latest version of this license is in [http://www.latex-project.org/lppl.txt](http://www.latex-project.org/lppl.txt) and version 1.3 or later is part of all distributions of LaTeX
version 2005/12/01 or later.

---
This work has the LPPL maintenance status _maintained_.
The current maintainer of this work is [Lukas C. Bossert](https://github.com/LukasCBossert).

