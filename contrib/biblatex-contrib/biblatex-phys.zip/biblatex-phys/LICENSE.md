Released under the [LaTeX Project Public
License](http://www.latex-project.org/lppl.txt), v1.3c or later.

The package has status 'maintained': the current maintainer is
[Joseph Wright](joseph.wright@morningstar2.co.uk).