bibLaTeX-__ijsra__    
======= 

_2016/07/04 v0.1_

Copyright (c) 2016 Lukas C. Bossert 

Email: [lukas@digitales-altertum.de](mailto:lukas@digitales-altertum.de)

This citation-style covers the citation and bibliography rules of 
the journal __[International Journal of Student Research in Archaeology](http://www.ijsra.org) (IJSRA)__. 

---

This style contains:

documentation:

- ijsra.tex
- ijsra.pdf

mandatory:

* ijsra.bbx
* ijsra.cbx


This work may be distributed and/or modified under the
conditions of the LaTeX Project Public License, either version 1.3
of this license or (at your option) any later version.
The latest version of this license is in [http://www.latex-project.org/lppl.txt](http://www.latex-project.org/lppl.txt) and version 1.3 or later is part of all distributions of LaTeX
version 2005/12/01 or later.

---
This work has the LPPL maintenance status _maintained_.
The current maintainer of this work is [Lukas C. Bossert](https://github.com/LukasCBossert).

