#include "dbi_error_text.h"

/***** NOTE: do not remove default return error text line. *****/

typedef int STATUS ;

char *dbi_error_text (STATUS error)
{
    switch (error)
    {
 /* Do not remove the next line. More error text can be defined, however. */
 /* Use optgen/optgen/error_text.c as a guide.                            */
        default:                                return ("UNKNOWN_ERROR") ;
    }
}

