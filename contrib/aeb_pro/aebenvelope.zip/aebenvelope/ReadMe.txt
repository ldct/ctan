The AeB Pro eEnvelope System (APES)


LaTeX package that uses the concept of an eEnvelope to attached
files. The system uses any one of four provided eEnvelope templates,
or can use a custom designed template. The AeB Pro package is
required to attach documents to the eEnvelope. The AeB Pro, hence
eEnvelope, requires Acrobat Pro, version 7.0 or later, and requires
the document author to create PDF using distiller.

Be sure to get the latest aeb_pro.zip and acrotex.zip distributions
(in the latter case, all you need is acrotex_pack.zip) if you
already have installed the full distribution.

Unzip within the aeb_pro folder, and the zip file should create an
aebEvelope folder with the package files within. Refresh you file
name database, as needed, and read the documentation and try the examples,
apeb1.tex, ape2.tex, ape3.tex and ape4.tex.

Home page for this package is

http://www.math.uakron.edu/~dpstory/aeb_pro.html

Enjoy!

Now, I must get back to my retirement.

dps
05/17/07
