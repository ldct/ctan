----------------------------------------------------------------

Ukrainian language module for Babel, v1.3i

Released under the LaTeX Project Public License v1.3c or later.
See http://www.latex-project.org/lppl.txt

The package provides support for use of Babel in documents written in Ukrainian. The support is adapted for use both
under legacy TEX engines, and under X∃TEX and LuaTEX.

Based on Russian language module v1.3i by Igor A. Kotelnikov <kia999 at mail dot ru>.

The Current Maintainer is Sergiy Ponomarenko <sergiy.ponomarenko@gmail.com>.

1. INSTALLATION

- unpack babel-ukrainian.zip
- run "xelatex.exe ukraineb.dtx" (recommended)
  or "pdflatex.exe ukraineb.dtx";
  run "tex.exe ukraineb.dtx"
  or "tex.exe ukraineb.ins", if you don't need documentation
- move "ukraineb.ldf" to <textmf>/tex/generic/babel/babel-ukrainian/
- move "ukraineb.pdf" and README to <textmf>/doc/generic/babel-ukrainian/
- update filename base (see documentation for your TeX system)

2. USAGE

Ukrainian language definition file can be used both with legacy 8-bit engines
(such as latex.exe or pdflatex.exe) and Unicode compilers (xelatex.exe or
lualatex.exe). The Unicode engines can be ran either in Unicode mode or 8-bit
compatibility mode, which emulates the legacy engines. The two modes differ by
a set of packages loaded in the preamble of a source TeX file. It is important
to keep recommended order of the packages loaded, especially when running
Unicode engines in a compatibility 8-bit mode.

In the examples below, it is assumed that a source file has utf8 input encoding.

2.1. 8-bit mode

2.1.1 PDFLATeX, LaTeX

    \usepackage[T1,T2A]{fontenc}
    \usepackage[utf8]{inputenc}
    \usepackage[english,ukrainian]{babel}

2.1.2 LuaLaTeX

    \usepackage[T1,T2A]{fontenc}
    \usepackage[lutf8]{luainputenc}
    \usepackage[english,ukrainian]{babel}

2.1.3 XeLaTeX

    \XeTeXinputencoding "bytes"
    \usepackage[utf8]{inputenc}
    \usepackage[T2A]{fontenc}
    \usepackage[english,ukrainian]{babel}

2.2 Unicode mode, LuaLaTeX or XeLaTeX

    \usepackage{fontspec}
        \defaultfontfeatures{Ligatures={TeX}}
        \setmainfont{CMU Serif}
        \setsansfont{CMU Sans Serif}
        \setmonofont{CMU Typewriter Text}
    \usepackage[english,ukrainian]{babel}

Instead of the Computer Modern Unicode (CMU) fonts loaded in this example,
you may try any True Type or Open Type font installed on your computer provided
that that font came with Ukrainian letters.

3. DOCUMENTATION

See ukraineb.pdf for more information.

4. KNOWN PROBLEMS

Before switching from a legacy 8-bit engine (tex, pdftex) to an Unicode
engine (xetex, luatex) and vise versa delete all .aux, .toc, .lot, .lof
files as they might have stored incompatible internal encodings.

5. CHANGES

2017-06-08 version 1.3i

    * Corrections according to new standart

2017-06-06 version 1.3h

    * Initial version

Original source:  russianb.dtx,
    2017-01-12 v1.3i Ukrainian support from the babel system.

----------------------------------------------------------------
