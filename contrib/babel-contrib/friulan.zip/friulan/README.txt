Package: babel-friulan


The package provides a language definition file for use with babel, which establishes 
Friulan conventions in a document (or a subset of the conventions, if Friulan is not 
the main language of the document).


To install run the friulan.dtx file trough pdfLaTeX; you get with the same run 
both the language description file and the documentation. Then you have to 
move the created friulan.ldf file into a directory searched by TeX.

This material is subject to the LaTeX Project Public License v1.3. 
See http://ctan.org/license/lppl1.3 for the details of that license.

Happy TeXing.

--------------------------------------

Claudio Beccari
claudio dot beccari at gmail dot com