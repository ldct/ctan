Icelandic 1.2b
--------------

This is the babel style for Icelandic.

Changes 1.2a
------------

* It now works with LuaTeX
* UTF-8 encoded strings for XeTeX and LuaTeX
* Old icelandic with inputenc utf8

Changes 1.2b
------------

* Warning with xe/lua without EUx (and documented)

----------
2016-01-14