
%----- Beef up the graphics ---------------------

function grphset(fHnd,PP)

FntNme = 'Times New Roman';
FntSze = 10;
FntAng = 'normal';
GrfLnW = .01;

set(fHnd,'PaperType','a4letter', ...
         'PaperOrientation','portrait', ...
         'PaperUnits','centimeters', ...
         'PaperPosition',PP);

aHnd = get(fHnd,'Children');

for j = 1:length(aHnd)
   set(aHnd(j),               'FontName',FntNme, 'FontSize',FntSze, 'FontAngle', FntAng);
   set(get(aHnd(j),'Title' ), 'FontName',FntNme, 'FontSize',FntSze, 'FontAngle', FntAng);
   set(get(aHnd(j),'XLabel'), 'FontName',FntNme, 'FontSize',FntSze, 'FontAngle', FntAng);
   set(get(aHnd(j),'YLabel'), 'FontName',FntNme, 'FontSize',FntSze, 'FontAngle', FntAng);  
   set(get(aHnd(j),'ZLabel'), 'FontName',FntNme, 'FontSize',FntSze, 'FontAngle', FntAng);

   chHnd = get(aHnd(j),'Children');

   for i=1:length(chHnd)
      if get(chHnd(i),'Type')=='line'
         set(chHnd(i),'LineWidth',GrfLnW);
      end
      if get(chHnd(i),'Type')=='text'
         set(chHnd(i),'FontName',FntNme,'FontSize',FntSze, 'FontAngle', FntAng);
      end
   end
end



