----------------------
   Graphic files
----------------------

   - unitstep.m   (Matlab source file)
   - grphset.m    (Matlab function)

   - fig1.mp      (MetaPost)
   - fig2.mp      (MetaPost)
 
   - MPfig.bat    (Dos batch file)

 The graphics were generated with Matlab and exported as eps
 files. With aid of GSview the eps files were translated to
 MetaPost source and edited by hand to obtain the current format
 
 
 Compilation:

 1. Edit mphead.tex for your font requirements.

 2. On Windows use MPfig.bat to obtain the mps
    and eps graphics output files:

      MPfig fig1
      MPfig fig2

    otherwise manually (e.g. for fig1.mp):

    a) mpost -tex=latex fig1.mp

    b) copy fig1.1 fig1.mps

    c) Make a tex file fig1.tex

            \input{mphead}
            \usepackage[dvips]{graphicx}
            \pagestyle{empty}
            \begin{document}
            \includegraphics{fig1.1}
            \end{document}

    d) latex fig1.tex
    e) dvips -Ppdf -G0 -E fig1.dvi     (makes eps file)

    f) delete all the temporary files

