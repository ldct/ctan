wn = 100;
xi = 0.4;


A = sqrt(1-xi*xi);
alf = atan(A/xi);

t = [0:.1:12];

y = 1- exp(-xi*t)/A .* sin(t*A+alf);

plot(t,y)
axis([0 12 0 1.4])
xlabel('time t')
ylabel('Displacement, x')
xlabel('Time, t')

grphset(gcf,[3 10 8 6])


